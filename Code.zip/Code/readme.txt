1.polyapdf.m
Neyman type A probability density function

2.dydt=odefcn.m
dydt=odefcn(y,N,beta,gammar,gammam) returns the differential equations of an SIRD epidemic model

3. infer_reporting_delays_realdata.m
Uncover reporting delay in real data(e.g. Spain)

4. SIRD_report_delay_synethic.m
Uncover reporting delay in generated synthetic dataset

5. Camp_Scatter.py
Plot the relation between I, delta R and delta D

6. correlation.m
Plot reproted I, delta R and delta D with the change of Day.